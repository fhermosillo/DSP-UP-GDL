/*
 * 	I2SDriver.h
 *
 *  Author: Fernando Hermosillo Reynoso
 * 	fernando.hermosillo@hotmail.com
 */

#ifndef __I2SDRIVER_H
#define __I2SDRIVER_H

#include <Arduino.h>
#include <cmath>

// include espressif hw files
#include <driver/i2s.h>

class I2SDriver {
public:
  I2SDriver(i2s_port_t _i2s_port = I2S_NUM_0, uint8_t _bclk_pin = 27, uint8_t _lrck_pin = 26, int8_t _dout_pin = 25, int8_t _din_pin = I2S_PIN_NO_CHANGE, int8_t _mck_pin = I2S_PIN_NO_CHANGE);
  
  // I2S init/deinit methods
  esp_err_t setup(uint32_t _sample_rate = 16000, uint32_t _buffer_size = 32, uint8_t _channel_count = 2, i2s_bits_per_sample_t _bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT, i2s_channel_fmt_t _channel_fmt = I2S_CHANNEL_FMT_RIGHT_LEFT);
  void close(void);

  // I2S start/stop methods  
  esp_err_t start(void);
  esp_err_t stop(void);

  // I2S W/R methods
  bool writeItem(void *src);                                // Write item to I2S directly
  bool writeFrame(void *frame);                             // Write a sample sample will be 
  bool readItem(void *dst);                                 //

  template<typename T>
  void writeToBlock(float src, uint8_t channel, uint32_t n);  // Write to buffer (not to I2S
  template<typename T>
  float readFromBlock(uint8_t channel, uint32_t n);         // Read from buffer (not from I2S)  
  size_t writeBlock(void);                                  // Write buffer to I2S
  size_t readBlock(void);                                   // Read buffer from I2S
  
  uint8_t ChannelCount(void);
  size_t BufferSize(void);
  
  // Data type conversions methods
  template<typename T>
  T toInteger(float sample) {
    // Saturation
    sample = min(sample, 1.0F-mInt2FloatScale);
    sample = max(sample, -1.0F);
    
    // Conversion
    sample *= mFloat2IntScale;
    
    return (T)(sample);
  }

  template<typename T>
  float toFloat(T sample) {
    return (float)(sample) * mInt2FloatScale;
  }

  // Get methods
  
  
  // Destructor method
  ~I2SDriver();
  


private:
  // I2S pinout
  i2s_pin_config_t i2s_pinout;

  // I2S ESP32 parameters
  i2s_port_t i2s_port;
  i2s_config_t i2s_config;
  uint8_t mChannelCount;
  i2s_mode_t i2s_mode;

  // I2S parameters
  bool need_tx;
  bool need_rx;
  uint32_t sample_rate;
  uint32_t buffer_size;
  int8_t *wr_buffer;
  int8_t *rd_buffer;

  float mInt2FloatScale;
  float mFloat2IntScale;
  uint8_t mBytesPerSample;
  
};

#endif /* __I2SDRIVER_H */